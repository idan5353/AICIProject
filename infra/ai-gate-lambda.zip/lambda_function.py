import json
import boto3
from botocore.exceptions import BotoCoreError, ClientError

# Bedrock runtime client – region must match where you enabled the model
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")

# Replace this with an ENABLED, cost-efficient model in your account, e.g.:
# - "anthropic.claude-3-haiku-20240307-v1:0" (if active)
# - or "mistral.mistral-small-2402-v1:0"
MODEL_ID = "anthropic.claude-3-5-haiku-20241022-v1:0"


def build_bedrock_prompt(event, decision, risk_score, reasons):
    commit_sha = event.get("commit_sha")
    branch = event.get("branch")
    tests = event.get("tests", {})
    diff = event.get("diff", {})
    service = event.get("service", {})

    files_changed = diff.get("files_changed", 0)
    insertions = diff.get("insertions", 0)
    deletions = diff.get("deletions", 0)

    prompt = f"""
You are an expert DevOps assistant helping to review CI/CD deployments.

Here is the deployment context as JSON:

event = {json.dumps(event, indent=2)}

The system has already computed this deployment decision:

- decision: {decision}
- risk_score: {risk_score}
- reasons: {json.dumps(reasons)}

Task:
1. Briefly explain whether deploying this change is low, medium, or high risk.
2. Justify the risk level using tests and change size.
3. Keep the explanation to 3–5 concise sentences.

Respond with plain text only, no markdown.
"""
    return prompt.strip()


def call_bedrock_for_explanation(prompt: str) -> str:
    body = json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 256,
            "temperature": 0.3,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt,
                        }
                    ],
                }
            ],
        }
    )

    try:
        response = bedrock.invoke_model(
            modelId=MODEL_ID,
            body=body,
        )
        response_body = json.loads(response["body"].read())
        # Claude-style response format
        content = response_body["content"][0]["text"]
        return content.strip()
    except (KeyError, BotoCoreError, ClientError, Exception) as e:
        return f"Bedrock explanation unavailable due to error: {str(e)}"


def lambda_handler(event, context):
    # --- 1. Parse inputs ---
    tests = event.get("tests", {})
    diff = event.get("diff", {})
    service = event.get("service", {})

    test_status = tests.get("status", "unknown")
    files_changed = int(diff.get("files_changed", 0))
    insertions = int(diff.get("insertions", 0))
    deletions = int(diff.get("deletions", 0))
    total_lines_changed = insertions + deletions

    # --- 2. Rule-based decision ---
    decision = "approve"
    reasons = []

    if test_status != "passed":
        decision = "block"
        reasons.append(f"Tests did not pass (status={test_status}).")
    else:
        reasons.append("All tests passed.")

        if files_changed > 10 or total_lines_changed > 500:
            decision = "warn"
            reasons.append(
                f"Large change set detected ({files_changed} files, {total_lines_changed} lines)."
            )
        else:
            reasons.append(
                f"Change set size appears moderate ({files_changed} files, {total_lines_changed} lines)."
            )

    risk_score = min(100, total_lines_changed // 10 + (20 if decision == "block" else 0))

    # --- 3. Bedrock natural-language explanation (cost-aware) ---
    if decision == "block":
        # Save cost: no Bedrock call if we already know we are blocking
        explanation = "Deployment blocked because tests did not pass. No Bedrock call made."
    else:
        prompt = build_bedrock_prompt(event, decision, risk_score, reasons)
        explanation = call_bedrock_for_explanation(prompt)

    # --- 4. Final response to GitHub Actions ---
    result = {
        "decision": decision,
        "risk_score": risk_score,
        "reasons": reasons,
        "explanation": explanation,
        "context": {
            "commit_sha": event.get("commit_sha"),
            "branch": event.get("branch"),
            "service_name": service.get("name"),
            "environment": service.get("environment"),
            "files_changed": files_changed,
            "total_lines_changed": total_lines_changed,
        },
    }

    return result