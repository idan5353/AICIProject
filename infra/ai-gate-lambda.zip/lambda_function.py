import json

def lambda_handler(event, context):
    # event is already a dict from the GitHub Actions payload
    commit_sha = event.get("commit_sha")
    branch = event.get("branch")
    tests = event.get("tests", {})
    diff = event.get("diff", {})
    service = event.get("service", {})

    test_status = tests.get("status", "unknown")
    files_changed = int(diff.get("files_changed", 0))
    insertions = int(diff.get("insertions", 0))
    deletions = int(diff.get("deletions", 0))

    total_lines_changed = insertions + deletions

    # Default decision values
    decision = "approve"
    reasons = []

    # 1) Hard block on failed tests
    if test_status != "passed":
        decision = "block"
        reasons.append(f"Tests did not pass (status={test_status}).")
    else:
        reasons.append("All tests passed.")

        # 2) Warn on large diffs
        if files_changed > 10 or total_lines_changed > 500:
            decision = "warn"
            reasons.append(
                f"Large change set detected ({files_changed} files, {total_lines_changed} lines)."
            )
        else:
            reasons.append(
                f"Change set size appears moderate ({files_changed} files, {total_lines_changed} lines)."
            )

    # Simple risk score: scale with lines changed, cap at 100
    risk_score = min(100, total_lines_changed // 10 + (20 if decision == "block" else 0))

    result = {
        "decision": decision,
        "risk_score": risk_score,
        "reasons": reasons,
        "context": {
            "commit_sha": commit_sha,
            "branch": branch,
            "service_name": service.get("name"),
            "environment": service.get("environment"),
            "files_changed": files_changed,
            "total_lines_changed": total_lines_changed,
        },
    }

    return result